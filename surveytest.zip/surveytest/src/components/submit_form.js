import '../App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import {Link, Redirect, useHistory} from 'react-router-dom'
import axios from 'axios';

class SubmitButton extends React.Component{
  constructor(props){
    super();
  }

  submitHandler = () => {
    this.props.submitted_answers["Time"] = ((new Date()) - this.props.time[0]) / 1000;
    for(var key in this.props.submitted_answers){
      if(typeof this.props.submitted_answers[key] == "object"){
      this.props.submitted_answers[key] = Array.from(this.props.submitted_answers[key]).join(" ");
    }
    }
    console.log(this.props.submitted_answers);

    axios.post('https://sheet.best/api/sheets/a0bca0c8-950c-498d-8595-f5e600ba554e', this.props.submitted_answers)
    .then(response => {
      console.log(response);
      return(
        <Redirect push to="/submitted" />
      );
    })
  }
  handleChange = e => {
      console.log("ANSWERS:");
      console.log(this.props.submitted_answers);
    };

    render() {
        return(
          <Link
            to="/submitted"
            onClick={this.submitHandler} >
            <div className="SubmitBox">
              <button>Submit!</button>
            </div>
            </Link>
          );
  };
}


export default SubmitButton;
