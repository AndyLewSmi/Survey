import '../App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import {Link, Redirect, useHistory} from 'react-router-dom'
import axios from 'axios';

class SubmitPage extends React.Component{
  constructor(props){
    super();
  }

    render() {
        return(
            <div className="SubmitBox">
              <p>
                Complete! It took you {this.props.time["Time"]} seconds!
                </p>
            </div>
          );
  };
}



export default SubmitPage;
