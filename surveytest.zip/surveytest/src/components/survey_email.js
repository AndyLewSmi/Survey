import '../App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import {Link, Redirect, useHistory} from 'react-router-dom'

class SurveyEmail extends React.Component{

  constructor(props){
    super(props);
    const setState = this.setState.bind(this);
    this.state = {
      selectedOption: "YES",
      redirect: false,
      email: ""
    };
  }
  submitHandler = () => {
    if (/^[\w!#$%&'*+\/=?^`{|}~-]+(?:\.[\w!#$%&'*+\/=?`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+(?:ac\.uk)$/.test(this.state.email)){
      this.props.submitted_answers["Email"] = this.state.email;
      this.props.timer[0] = (new Date());
      console.log("SUCCESS");
      this.setState({redirect: true});
    }
    else{
      console.log("FAIL");
    }
  }
  // <Link
    // to={this.props.default}
    // onClick={this.submitHandler} >


  handleChange = e => {
      this.state.email = e.target.value;
    };

    render() {
      if (this.state.redirect) {
          return <Redirect to={this.props.default} />
        }

      return(
      <div className="App">
        <div className="questionBox">
          <a>Please enter your email address:</a>
        </div>
        <div className="answerBox">
          <input type="text" onChange={this.handleChange}/>
            <div className="SubmitBox">

              <button onClick={this.submitHandler}>Start!</button>
            </div>
        </div>
      </div>
    );
  };
}


export default SurveyEmail;
