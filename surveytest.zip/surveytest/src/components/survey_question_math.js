import '../App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import {Link, Redirect, useHistory} from 'react-router-dom'
import Timer from './timer.js';
import { MathComponent } from 'mathjax-react';


class SurveyMath extends React.Component{

  constructor(props){
    super(props);
    const setState = this.setState.bind(this);
    this.state = {
      selectedOption: "YES",
      redirect: null,
      answered: false,
      an: null
    };
    console.log(props.timer);
    // this.props.timer.current.startTimer();
  }

  handleChange = e => {
      console.log("You mother fucker");
      const value = e.target;
      this.props.submitted_answers[this.props.number] = value.value;
      console.log(this.props.submitted_answers)
      this.setState({
        selectedOption: value.value,
        answered: true
      });
      return () => clearTimeout(this.state.timer);
    };

    handleClick = e => {
      if(this.state.answered){
        this.setState({
          redirect: true
        });
      }
    }

    render() {
      return(
      <div className="App">
        {this.props.submitted_answers[0] ? <Redirect to={this.props.default}/> : null}
      {this.props.image == null ? <br/> : <img src={process.env.PUBLIC_URL + 'images/' + this.props.image} alt="img" />}
        <div className="questionBox">
          <a>{this.props.question}</a>
          {this.props.math}
        </div>
        <div className="answerBox">
        {this.props.answer.map((an, index) => (
          <div className="singleAnswer">
          <Link to={this.props.routes[an]}>
           <input type="radio" value={an} name="answer_thing" onChange={this.handleChange}/>
           </Link>
           {an}
           </div>
            )
          )
        }
        </div>
        <button onClick={this.handleClick}>Next Question!</button>
        {this.state.redirect ? <Redirect to={this.props.routes[this.state.selectedOption]} /> : null}
      </div>
    );
  };
}


export default SurveyMath;
