import '../App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import Checkbox from '@material-ui/core/Checkbox';
import {Link, Redirect, useHistory} from 'react-router-dom'

class SurveyCheckbox extends React.Component{
  constructor(props){
    super(props);
    const setState = this.setState.bind(this);
    this.state = {
      selectedOption: "YES",
    };
    props.submitted_answers[props.number] = new Set()

  }


  handleChange = e => {
      if(this.props.submitted_answers[this.props.number] == "No Answer"){
        this.props.submitted_answers[this.props.number] = new Set();
      }
      console.log("Why?");
      console.log(this.props);
      const value = e.target;
      if(this.props.submitted_answers[this.props.number].has(value.value)){
        this.props.submitted_answers[this.props.number].delete(value.value);
      }
      else{
        this.props.submitted_answers[this.props.number].add(value.value);
      }
      console.log(this.props.submitted_answers)
      this.setState({
        selectedOption: value.value
      });
    };

    render() {
      return(
      <div className="App">
        {this.props.submitted_answers[0] ? <Redirect to={this.props.default}/> : null}
        <div className="questionBox">
          <a>{this.props.question}</a>
        </div>
        <div className="answerBox">
        {this.props.answer.map((an, index) => (
          <div className="singleAnswer">
          <Checkbox
             value={an}
             inputProps={{ 'aria-label': 'Checkbox A' }}
             onChange={this.handleChange}
            />
           {an}
           </div>
            )
          )
        }
        </div>
        <Link
          to={this.props.default}
          onClick={this.submitHandler}>
          <div className="SubmitBox">
            <button>Submit!</button>
        </div>
        </Link>
          </div>
          );
  };
}


export default SurveyCheckbox;
