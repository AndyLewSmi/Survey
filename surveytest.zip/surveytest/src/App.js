import './App.css';
import React from 'react';
import SurveyQuestion from './components/survey_question.js';
import SurveyMath from './components/survey_question_math.js';
import SubmitButton from './components/submit_form.js';
import SurveyCheckbox from './components/survey_question_checkbox.js';
import SubmitPage from './components/submitted_page.js';
import SurveyEmail from './components/survey_email.js';
import { Redirect, BrowserRouter as Router, Route, Link, MemoryRouter   } from "react-router-dom";
import {Switch, browserHistory} from "react-router-dom";
import { MathComponent } from 'mathjax-react';
// import Timer from './components/timer.js;'

// import Timer from './components/timer.js'


class App extends React.Component {
  constructor() {
    super();
    this.state = { time: {}, seconds: 1200 };
    this.timer = 0;
    this.startTimer = this.startTimer.bind(this);
    this.countDown = this.countDown.bind(this);
    this.resetTimer = this.resetTimer.bind(this);
    this.reset = false;
    this.stopped = false;
    this.gotten_time = false;
    this.inputRef = React.createRef(null);
    this.number_of_questions = 65

    this.question_1 = "This survey should last approximately 20-30 minutes. To continue to the next question, click NEXT. You will not be able to go back once you have clicked NEXT. The overview of the test and survey is outlined: Demographic questions, Numeracy test, Statistics test Maths anxiety survey, Survey of the impact of COVID-19 on your learning.";
    this.answer_1 = ["Next"];
    this.routes_1 = {"Next" : "question_2"};
    this.default_1 = "question_2";
    this.time_1 = 0.1;
    this.image_1 = "monkey.jpg";

    this.question_2 = "Do you agree to data from this survey to be sent to your department?";
    this.answer_2 = ["Yes", "No"];
    this.routes_2 = {"Yes" : "question_3", "No" : "question_3"};
    this.default_2 = "question_3";
    this.time_2 = 1;
    this.image_2 = null;

    this.question_3 = "This is some boilerplate mathematics";
    this.math_3 =  <MathComponent tex={String.raw`\int_0^1 x^2\ dx`} />
    this.answer_3 = ["Next"];
    this.routes_3 = {"Next" : "question_4"};
    this.default_3 = "question_4";
    this.time_2 = 1;
    this.image_2 = null;

    this.question_4 = "Do you agree to data from this survey to be used in this research project?";
    this.answer_4 = ["Yes", "No"];
    this.routes_4 = {"Yes" : "\email", "No" : "\email"};
    this.default_4 = "\email";
    this.time_4 = 1;
    this.image_4 = "monkey.jpg";

    this.answer_5 = ["17", "18","19", "20", "21","22","23", "24","25", "26+", "Prefer not to say"];
    this.question_5 = "What age are you?";
    this.routes_5 = {"17" : "question_6", "18" : "question_6","19" : "question_6", "20" : "question_6", "21" : "question_6","22" : "question_6","23" : "question_6", "24" : "question_6","25" : "question_6", "26+" : "question_6", "Prefer not to say" : "question_6"};
    this.default_5 = "question_6";
    this.time_5 = 1;
    this.image_5 = null;

    this.answer_6 = ["Male", "Female", "Other", "Prefer not to say"];
    this.question_6 = "To which gender do you most identify?";
    this.routes_6 = {"Male" : "question_7", "Female" : "question_7", "Other" : "question_7", "Prefer not to say" : "question_7"};
    this.default_6 = "question_7";
    this.time_6 = 1;
    this.image_6 = null;

    this.answer_7 = ["Yes", "No"];
    this.question_7 = "Did you study post-16 education in England, Wales or Northern Ireland?";
    this.routes_7 = {"Yes" : "question_8", "No" : "question_8"};
    this.default_7 = "question_8";
    this.time_7 = 1;
    this.image_7 = null;

    this.answer_8 = ["Yes", "No"];
    this.question_8 = "Did you study a mathematics or statistics qualification between the ages of 16-18?";
    this.routes_8 = {"Yes" : "question_9", "No" : "question_10"};
    this.default_8 = "question_9";
    this.time_8 = 1;
    this.image_8 = null;

    this.answer_9 = ["Level 3 Core Maths", "AS Level Mathematics", "A-Level Mathematics", "IB Maths"];
    this.question_9 = "Which of the following mathematics or statistics qualifications have you studied?";
    this.routes_9 = {"Level 3 Core Maths" : "question_10", "AS Level Mathematics" : "question_10", "A-Level Mathematics" : "question_10", "IB Maths" : "question_10"};
    this.default_9 = "question_10";
    this.time_9 = 1;
    this.image_9 = null;

    this.answer_10 = ["Yes", "No"];
    this.question_10 = "Did you study a foundation year at university?";
    this.routes_10 = {"Yes" : "question_11", "No" : "question_11"};
    this.default_10 = "question_11";
    this.time_10 = 1;
    this.image_10 = null;

    this.answer_11 = ["09:50", "11:00", "12:00", "14:00"];
    this.question_11 = "Buses for Colchester leave the bus station every 12 minutes. Buses for Ipswich leave the bus station every 50 minutes. A bus for Colchester and a bus for Ipswich leave the bus station together at 09:00. Assuming that all the buses leave on time, when is the next time that a bus for Colchester and a bus for Ipswich will leave the bus station together?";
    this.routes_11 = {"09:50" : "question_12", "11:00" : "question_12", "12:00" : "question_12", "14:00" : "question_12" };
    this.default_11 = "question_12";
    this.time_11 = 1;
    this.image_11 = null;

    this.answer_12 = ["120", "180", "195", "200"];
    this.question_12 = "The diagram below shows a cardboard box that has a width of 30 cm, a length of 40 cm and a height of 20 cm. There are flaps on the top and bottom which each have a width of 15 cm as shown. Samara is trying to pack the box with as many identical cartons as she can. The diagram below shows that each carton has a width of 2 cm, a length of 20 cm and a height of 3 cm. The cartons can be packed in the box in any orientation. What is the maximum number of cartons that will fit in the box?";
    this.routes_12 = {"120" : "question_13", "180" : "question_13", "195" : "question_13", "200" : "question_13"};
    this.default_12 = "question_13";
    this.time_12 = 1;
    this.image_12 = "lotsodepth.jpg";

    this.answer_13 = ["a", "b", "c", "d"];
    this.question_13 = "The diagram below shows a graph of against. What is the equation of the red line?";
    this.routes_13 = {"a" : "question_14", "b" : "question_14", "c" : "question_14", "d" : "question_14"};
    this.default_13 = "question_14";
    this.time_13 = 1;
    this.image_13 = "slope.jpg";

    this.answer_14 = ["4 metres", "40 metres", "400 metres", "4000 metres"];
    this.question_14 = "The diagram below shows the graph of . . . Each unit on the x and y axis is worth 1 cm. If represents length and represents height how long would the graph need to be, in metres, to reach a height of 2 metres?";
    this.routes_14 = {"4 metres" : "question_15", "40 metres" : "question_15", "400 metres" : "question_15", "4000" : "question_15"};
    this.default_14 = "question_15";
    this.time_14 = 1;
    this.image_14 = "slow.jpg";

    this.answer_15 = ["2", "50", "200", "500"];
    this.question_15 = "Drax Power Station is the UK’s largest power station located in North Yorkshire with a capacity to generate 3.9 GigaWatts of energy to meet the electrical needs of the UK. Due to climate change, the UK government is set to ban all electricity generated from burning coal by 2025. At the start of 2020, one third of energy generated by Drax Power Station was produced by burning coal. The remaining two thirds of energy came from biomass. An alternative to burning fuel is to use onshore wind turbines since they use a renewable energy source. Each onshore wind turbine can produce 2.6 MegaWatts of energy. Approximately how many onshore wind turbines would be required to replace the amount of energy that Drax Power Station generates from burning coal? 1 MegaWatt = 1,000,000 Watts, 1 GigaWatt = 1,000,000,000 Watts";
    this.routes_15 = {"2" : "question_16", "50" : "question_16", "200" : "question_16", "500" : "question_16"};
    this.default_15 = "question_16";
    this.time_15 = 1;
    this.image_15 = null;

    this.answer_16 = ["15 minutes", "50 minutes", "1 hour 50 minutes", "2 hours 30 minutes"];
    this.question_16 = "A particular lecture takes place 3 times a week. This lecture always starts 5 minutes later than planned due to students arriving late. How much time is lost in this lecture over the duration of a 10-week term?";
    this.routes_16 = {"15 minutes" : "question_17", "50 minutes" : "question_17", "1 hour 50 minutes" : "question_17", "2 hours 30 minutes" : "question_17"};
    this.default_16 = "question_17";
    this.time_16 = 1;
    this.image_16 = null;

    this.answer_17 = ["133", "150", "230", "260"];
    this.question_17 = "A charity is collecting 20 pence coins. It manages to collect a total of £26.60. How many 20 pence coins did the charity collect?";
    this.routes_17 = {"133" : "question_18", "150" : "question_18", "230" : "question_18", "260" : "question_18"};
    this.default_17 = "question_18";
    this.time_17 = 1;
    this.image_17 = null;

    this.answer_18 = ["300", "432", "3,000", "4,320"];
    this.question_18 = "A particular holiday costs 3,600 Euros. If the exchange rate is 1.2 Euros for every £1, how much does the holiday cost in Pounds Sterling?";
    this.routes_18 = {"300" : "question_19", "432" : "question_19", "3,000" : "question_19", "4,320" : "question_19"};
    this.default_18 = "question_19";
    this.time_18 = 1;
    this.image_18 = null;

    this.answer_19 = ["10", "15", "20", "25"];
    this.question_19 = "The temperatures of Liquid A and Liquid B are measured using two different thermometers. The diagram below shows the temperature readings on the two thermometers. How many degrees hotter is Liquid A than liquid B?";
    this.routes_19 = {"10" : "question_20", "15" : "question_20", "20" : "question_20", "25" : "question_20"};
    this.default_19 = "question_20";
    this.time_19 = 1;
    this.image_19 = "liquidAB.jpg";

    this.answer_20 = ["7%", "13%", "27%", "35%"];
    this.question_20 = "A pencil case consists of 20 coloured pencils. 8 pencils are red, 5 pencils are green and the remaining pencils are blue. What percentage of the coloured pencils are blue?";
    this.routes_20 = {"7%" : "question_21", "13%" : "question_21", "27%" : "question_21", "35%" : "question_21"};
    this.default_20 = "question_21";
    this.time_20 = 1;
    this.image_20 = null;

    this.answer_21 = ["2 times", "4 times", "8 times", "16 times"];
    this.question_21 = "a and b  are two numbers. If a and b are both doubled, how many times will (ab)^2 increase?";
    this.routes_21 = {"2 times" : "question_22", "4 times" : "question_22", "8 times" : "question_22", "16 times" : "question_22" };
    this.default_21 = "question_22";
    this.time_21 = 1;
    this.image_21 = null;

    this.answer_22 = ["0.001", "10^-4", "1% of 1"];
    this.question_22 = "Which of these is the smallest: 0.001, 10^-4, 1% of 1";
    this.routes_22 = {"0.001" : "question_23", "10^-4" : "question_23", "1% of 1" : "question_23"};
    this.default_22 = "question_23";
    this.time_22 = 1;
    this.image_22 = null;

    this.answer_23 = ["4", "5", "6", "7"];
    this.question_23 = "A school canteen is making soup for lunch. It anticipates that it will need to serve 800 bowls of soup. Each bowl contains 400 millilitres of soup. The canteen cooks the soup in large saucepans that can hold up to 50 litres of soup. How many saucepans will the canteen need to use in order to serve 800 bowls of soup for lunch?";
    this.routes_23 = {"4" : "question_24", "5" : "question_24", "6" : "question_24", "7" : "question_24"};
    this.default_23 = "question_24";
    this.time_23 = 1;
    this.image_23 = null;

    this.answer_24 = ["24 miles", "27 miles", "37 miles", "52 miles"];
    this.question_24 = "Two cyclists go out for a bike ride together. Cyclist A is from the UK and is used to working in miles, whereas Cyclist B is from France and is used to working in kilometres. At the end of the ride they compare distances. Cyclist B cycled 25 kilometres, whereas because Cyclist A lives a little further away, he cycled a further 12 miles. What is the total distance that Cyclist A cycled in miles? 10 kilometres 6 miles?";
    this.routes_24 = {"24 miles" : "question_25", "27 miles" : "question_25", "37 miles" : "question_25", "52 miles" : "question_25"};
    this.default_24 = "question_25";
    this.time_24 = 1;
    this.image_24 = null;

    this.answer_25 = ["13 years and 7 months", "13 years and 11 months", "14 years and 4 months", "14 years and 7 months"];
    this.question_25 = "An assessment finds that a student has a reading age of 15 years and 3 months. Exactly a year ago the same student had a reading age that was 16 months lower. What was the student’s reading age a year ago?";
    this.routes_25 = {"13 years and 7 months" : "question_26", "13 years and 11 months" : "question_26", "14 years and 4 months" : "question_26", "14 years and 7 months" : "question_26"};
    this.default_25 = "question_26";
    this.time_25 = 1;
    this.image_25 = null;

    this.answer_26 = ["Next"];
    this.question_26 = "You will now be asked some statistical reasoning questions. You will have a maximum of 20 minutes to complete this section. You are advised to spend approximately 1 minute on each question. Once the timer has finished you will advance to the next section automatically, even if you have not submitted an answer for that question. Before each question you will be asked to rate how confident you are feeling on a scale from 1 to 4. For each question you will be given a set of multiple choice options to choose from. Please select ONE option. You must answer the questions WITHOUT A CALCULATOR, however rough working is allowed. You will then be asked to rate how confident you feel about your answer to each question on a scale from 1 to 4. When you have selected an option AND rated your confidence level, please select the NEXT button.";
    this.routes_26 = {"Next" : "question_27"};
    this.default_26 = "question_27";
    this.time_26 = 1;
    this.image_26 = null;

    this.answer_27 = ["30", "37.5", "40", "75"];
    this.question_27 = "60 students sit a test. The students are divided into two groups. The mean mark of the 20 students in group A is 30. The mean mark of group B is 45. What is the mean mark of all 60 students?";
    this.routes_27 = {"30": "question_28", "37.5" : "question_28", "40" : "question_28", "75": "question_28" };
    this.default_27 = "question_28";
    this.time_27 = 1;
    this.image_27 = null;

    this.answer_28 = ["60", "540", "60,000", "540,000"];
    this.question_28 = "The table below shows data about the transactions made by a clothing retailer. Approximately how many items were bought in-store?";
    this.routes_28 = {"60" : "question_29", "540" : "question_29", "60,000" : "question_29", "540,000" : "question_29"};
    this.default_28 = "question_29";
    this.time_28 = 1;
    this.image_28 = "typeoftrans.jpg";

    this.answer_29 = ["15 mph", "23 mph", "28 mph", "33 mph"];
    this.question_29 = "The graph below shows weather data from four UK counties (Berkshire, Cornwall, Durham and Essex) over a four-month period. What was the average wind speed between March and June for Cornwall?";
    this.routes_29 = {"15 mph" : "question_30", "23 mph" : "question_30", "28 mph" : "question_30", "33 mph" : "question_30"};
    this.default_29 = "question_30";
    this.time_29 = 1;
    this.image_29 = "avgwindspeed.jpg";

    this.answer_30 = ["10 mm", "70 mm", "80 mm", "90 mm"];
    this.question_30 = "The graph below shows weather data from four UK counties (Berkshire, Cornwall, Durham and Essex) over a four-month period. How much more rain did Cornwall get than Essex, on average, during June?";
    this.routes_30 = {"10 mm" : "question_31", "70 mm" : "question_31", "80 mm" : "question_31", "80 mm" : "question_31"};
    this.default_30 = "question_31";
    this.time_30 = 1;
    this.image_30 = "avgrainfall.jpg";

    this.answer_31 = ["Berkshire", "Cornwall", "Durham", "Essex"];
    this.question_31 = "The graph below shows weather data from four UK counties (Berkshire, Cornwall, Durham and Essex) over a four-month period. Which county had the biggest difference in temperature during the four-month period?";
    this.routes_31 = {"Berkshire" : "question_32", "Cornwall" : "question_32", "Durham" : "question_32", "Essex" : "question_32"};
    this.default_31 = "question_32";
    this.time_31 = 1;
    this.image_31 = "avgtemp.jpg";

    this.answer_32 = ["2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017"];
    this.question_32 = "A university department is looking at the applicant data for a particular degree scheme. The graph below shows the number of applicants to the degree scheme and the number of offers which were accepted between the years 2010 to 2018. Which year had the highest percentage of applicants accepting their offers?";
    this.routes_32 = {"2010" : "question_33", "2011" : "question_33", "2012" : "question_33", "2013" : "question_33", "2014" : "question_33", "2015" : "question_33", "2016" : "question_33", "2017" : "question_33"};
    this.default_32 = "question_33";
    this.time_32 = 1;
    this.image_32 = "distrofappandoff.jpg";

    this.answer_33 = ["150", "70", "200", "120"];
    this.question_33 = "30 fish were caught in a pond; each one was tagged and then released. The next day, 50 fish were caught and 10 were found to have tags on. Estimate the total number of fish in the pond.";
    this.routes_33 = {"150" : "question_34", "70" : "question_34", "200" : "question_34", "120" : "question_34" };
    this.default_33 = "question_34";
    this.time_33 = 1;
    this.image_33 = null;

    this.answer_34 = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov","Dec"];
    this.question_34 = "The heights of two plants, Plant A and Plant B, were measured every month. Here is the graph of their growth: Plant A was damaged during the year. Based on the graph above, during which month did the damage most-likely happen?";
    this.routes_34 = {"Jan" : "question_35", "Feb" : "question_35", "Mar" : "question_35", "Apr" : "question_35", "May" : "question_35",  "Jun" : "question_35", "Jul" : "question_35", "Aug" : "question_35", "Sep" : "question_35", "Oct" : "question_35", "Nov" : "question_35", "Dec" : "question_35"};
    this.default_34 = "question_35";
    this.time_34 = 1;
    this.image_34 = "heightspermonth.jpg";

    this.answer_35 = ["No effects of alcohol" , "No effects of sleep deprivation", "An interaction effect between alcohol and sleep deprivation",  "No effects of alcohol or sleep deprivation"];
    this.question_35 = "Participants were recruited for an experiment and put into three groups. The first group was not given any alcohol and was exposed to sleep deprivation. The second group was instructed to drink 3 units of alcohol prior to starting the experiment and was exposed to sleep deprivation. The final group was used as a control group; they were not given any alcohol and not exposed to sleep deprivation. The graph below shows the ability for the first and second group to complete a task during different stages of sleep deprivation. The mean error measures the average difference from the control group to complete the same task. Which of the following conclusions can be drawn from this graph?";
    this.routes_35 = {"No effects of alcohol" : "question_36", "No effects of sleep deprivation" : "question_36", "An interaction effect between alcohol and sleep deprivation" : "question_36", "No effects of alcohol or sleep deprivation" : "question_36"};
    this.default_35 = "question_36";
    this.time_35 = 1;
    this.image_35 = "alcsleepdepr.jpg";

    this.answer_36 = ["A", "B", "C", "D"];
    this.question_36 = "The heights of a group of 30 students are plotted in the following cumulative frequency graph. The same data is plotted in a box plot. Which of the following box plots corresponds with the cumulative frequency graph shown above?";
    this.routes_36 = {"A": "question_37", "B" : "question_37", "C" : "question_37", "D" : "question_37"};
    this.default_36 = "question_37";
    this.time_36 = 1;
    this.image_36 = "heightcm.jpg";

    this.answer_37 = ["5kg","10kg","30kg","38kg"];
    this.question_37 = "The histogram below shows the weights in kg of a group of animals in a zoo. Find an estimate for the mean weight of the animals in kg.";
    this.routes_37 = {"5kg": "question_38", "10kg" : "question_38", "30kg" : "question_38", "38kg" : "question_38"};
    this.default_37 = "question_38";
    this.time_37 = 1;
    this.image_37 = "histofweight.jpg";

    this.answer_38 = ["y = 574x + 27122", "y = 27122x + 574", "y = -574x + 27122", "y = -27122x + 574"];
    this.question_38 = "The scatter plot below shows the relationship between salary () and years of experience () in a particular company. The regression line (line of best fit) for the given data is drawn on the scatter plot. What is the equation of the regression line?";
    this.routes_38 = {"y = 574x + 27122": "question_39", "y = 27122x + 574" : "question_39", "y = -574x + 27122" : "question_39", "y = -27122x + 574" : "question_39"};
    this.default_38 = "question_39";
    this.time_38 = 1;
    this.image_38 = "salaryagainst.jpg";

    this.answer_39 = ["The fastest recorded time was seconds faster than the next fastest time", "The slowest recorded time was seconds slower than the next slowest time",  "Every year, the runners are approximately seconds slower than the last year", "Every year, the runners are approximately seconds faster than the last year"];
    this.question_39 = "A linear model is proposed for the winning 100m sprint time at the Athletics Championships. Let represent the winning runner’s time for that year, in seconds. Let represent the year in which the time was set. The equation of the regression line (line of best fit) is which statement describes what the means in the regression equation?";
    this.routes_39 = {"The fastest recorded time was seconds faster than the next fastest time": "question_40", "The slowest recorded time was seconds slower than the next slowest time" : "question_40",  "Every year, the runners are approximately seconds slower than the last year" : "question_40"};
    this.default_39 = "question_40";
    this.time_39 = 1;
    this.image_39 = null;

    this.answer_40 = ["36%","51%", "55%", "90%"];
    this.question_40 = "A class of students were asked whether they preferred mathematics or statistics. Each student had to choose exactly one subject. The two-way table shows which subject was preferred and which gender the students identified to. A student is chosen from the class at random. Given that the student is male, what is the probability that this student prefers mathematics?";
    this.routes_40 = {"36%": "question_41", "51%" : "question_41", "55%" : "question_41", "90%" : "question_41"};
    this.default_40 = "question_41";
    this.time_40 = 1;
    this.image_40 = "mathsvstats.jpg";

    this.answer_41 = ["5,040 years old", "5,280 years old", "5,400 years old", "5,500 years old"];
    this.question_41 = "TA historic artifact is discovered by a team of archaeologists. The archaeologists want to determine how old the artifact is. Three tests are conducted which have varying levels of accuracy. Test 1: historical records tell them that the age is 5,400 +/- 120 years old Test 2: relative dating tells them that the age is between 5,500 and 6,000 years old Test 3: radiocarbon dating gives the age as 5,600 years old with an error margin of 10%What is the minimum age of the artifact that is consistent with all three tests?";
    this.routes_41 = {"5,040 years old": "submit", "5,280 years old" : "submit", "5,400 years old" : "submit", "5,500 years old" : "submit"};
    this.default_41 = "submit";
    this.time_41 = 1;
    this.image_41 = null;

    this.answer_42 = ["Next"];
    this.question_42 = "You will now be presented with some everyday situations. Please rate each of the following items in terms of how anxious you would feel during the event specified";
    this.routes_42 = {"Next": "question_43"};
    this.default_42 = "question_43";
    this.time_42 = 1;
    this.image_42 = null;

    this.answer_43 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_43 = "How anxious do you feel having to work with fractions?";
    this.routes_43 = {"Low anxiety": "question_44", "Some anxiety" : "question_44", "Moderate anxiety" : "question_44", "Quite a bit of anxiety" : "question_44"};
    this.default_43 = "question_44";
    this.time_43 = 1;
    this.image_43 = null;

    this.answer_44 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_44 = "How anxious do you feel having to work with percentages?";
    this.routes_44 = {"Low anxiety": "question_45", "Some anxiety" : "question_45", "Moderate anxiety" : "question_45", "Quite a bit of anxiety" : "question_45"};
    this.default_44 = "question_45";
    this.time_44 = 1;
    this.image_44 = null;

    this.answer_45 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_45 = "How anxious do you feel having to work out a 15% tip?";
    this.routes_45 = {"Low anxiety": "question_46", "Some anxiety" : "question_46", "Moderate anxiety" : "question_46", "Quite a bit of anxiety" : "question_46"};
    this.default_45 = "question_46";
    this.time_45 = 1;
    this.image_45 = null;

    this.answer_46 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_46 = "How anxious do you feel figuring out how much a shirt will cost if it is 25% off?";
    this.routes_46 = {"Low anxiety": "question_47", "Some anxiety" : "question_47", "Moderate anxiety" : "question_47", "Quite a bit of anxiety" : "question_47"};
    this.default_46 = "question_47";
    this.time_46 = 1;
    this.image_46 = null;

    this.answer_47 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_47 = "How anxious do you feel having to work out prices in a foreign currency";
    this.routes_47 = {"Low anxiety": "question_48", "Some anxiety" : "question_48", "Moderate anxiety" : "question_48", "Quite a bit of anxiety" : "question_48"};
    this.default_47 = "question_48";
    this.time_47 = 1;
    this.image_47 = null;

    this.answer_48 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_48 = "How anxious do you feel looking at tables and graphs when reading a newspaper?";
    this.routes_48 = {"Low anxiety": "question_49", "Some anxiety" : "question_49", "Moderate anxiety" : "question_49", "Quite a bit of anxiety" : "question_49"};
    this.default_48 = "question_49";
    this.time_48 = 1;
    this.image_48 = null;

    this.answer_49 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_49 = "How anxious do you feel being presented with numerical information about different mobile phone subscription options";
    this.routes_49 = {"Low anxiety": "question_50", "Some anxiety" : "question_50", "Moderate anxiety" : "question_50", "Quite a bit of anxiety" : "question_50"};
    this.default_49 = "question_50";
    this.time_49 = 1;
    this.image_49 = null;

    this.answer_50 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_50 = "How anxious do you feel having to choose between financial investment options?";
    this.routes_50 = {"Low anxiety": "question_51", "Some anxiety" : "question_51", "Moderate anxiety" : "question_51", "Quite a bit of anxiety" : "question_51"};
    this.default_50 = "question_51";
    this.time_50 = 1;
    this.image_50 = null;

    this.answer_51 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_51 = "How anxious do you feel reading your bank's leaflet about changes in terms of using your credit card";
    this.routes_51 = {"Low anxiety": "question_52", "Some anxiety" : "question_52", "Moderate anxiety" : "question_52", "Quite a bit of anxiety" : "question_52"};
    this.default_51 = "question_52";
    this.time_51 = 1;
    this.image_51 = null;

    this.answer_52 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_52 = "How anxious do you feel having to complete a maths course as part of your work training?";
    this.routes_52 = {"Low anxiety": "question_53", "Some anxiety" : "question_53", "Moderate anxiety" : "question_53", "Quite a bit of anxiety" : "question_53"};
    this.default_52 = "question_53";
    this.time_52 = 1;
    this.image_52 = null;

    this.answer_53 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_53 = "How anxious do you feel having to sit a numeracy test as part of a job application process?";
    this.routes_53 = {"Low anxiety": "question_54", "Some anxiety" : "question_54", "Moderate anxiety" : "question_54", "Quite a bit of anxiety" : "question_54"};
    this.default_53 = "question_54";
    this.time_53 = 1;
    this.image_53 = null;

    this.answer_54 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_54 = "How anxious do you feel having to present numerical information at a work meeting?";
    this.routes_54 = {"Low anxiety": "question_55", "Some anxiety" : "question_55", "Moderate anxiety" : "question_55", "Quite a bit of anxiety" : "question_55", "High anxiety" : "question_55"};
    this.default_54 = "question_55";
    this.time_54 = 1;
    this.image_54 = null;

    this.answer_55 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_55 = "How anxious do you feel having to present numerical information at a work meeting?";
    this.routes_55 = {"Low anxiety": "question_56", "Some anxiety" : "question_56", "Moderate anxiety" : "question_56", "Quite a bit of anxiety" : "question_56", "High anxiety" : "question_56"};
    this.default_55 = "question_56";
    this.time_55 = 1;
    this.image_55 = null;

    this.answer_56 = ["Low anxiety", "Some anxiety", "Moderate anxiety", "Quite a bit of anxiety", "High anxiety"];
    this.question_56 = "How anxious do you feel making an important decision in the workplace based on last year's statistical reports?";
    this.routes_56 = {"Low anxiety": "question_57", "Some anxiety" : "question_57", "Moderate anxiety" : "question_57", "Quite a bit of anxiety" : "question_57", "High anxiety" : "question_57"};
    this.default_56 = "question_57";
    this.time_56 = 1;
    this.image_56 = null;

    this.answer_57 = ["Yes", "No"];
    this.question_57 = "Were you in education at the time of the COVID-19 (Coronavirus) outbreak?";
    this.routes_57 = {"Yes": "question_58", "No" : "question_59"};
    this.default_57 = "question_58";
    this.time_57 = 1;
    this.image_57 = null;

    this.answer_58 = ["I had mostly face-to-face lessons that took place in a classroom", "I had mostly online lessons", "I had an even split between online lessons and face-to-face lessons in a classroom", "I did not have any lesson"];
    this.question_58 = "Where did the majority of your lessons take place during the COVID-19 (Coronavirus) outbreak (after March 2020)?";
    this.routes_58 = {"I had mostly face-to-face lessons that took place in a classroom": "question_59", "I had mostly online lessons" : "question_59", "I had an even split between online lessons and face-to face lessons in a classroom" : "question_59", "I did not have any lesson" : "question_59"};
    this.default_58 = "question_59";
    this.time_58 = 1;
    this.image_58 = null;

    this.answer_59 = ["Next"];
    this.question_59 = "You will now be presented with a series of questions regarding the impact that COVID-19 (Coronavirus) has had on your education between March 2020 and the present day. Please select your agreement with each of the statements given.";
    this.routes_59 = {"Next": "question_60"};
    this.default_59 = "question_60";
    this.time_59 = 1;
    this.image_59 = null;

    this.answer_60= ["Strongly Disagree", "Somewhat Disagree", "Neither Agree nor Disagree", "Somewhat Agree", "Strongly Agree"];
    this.question_60 = "COVID-19 had no impact on my education.";
    this.routes_60 = {"Strongly Disagree": "question_61", "Somewhat Disagree" : "question_61", "Neither Agree nor Disagree" : "question_61", "Somewhat Agree" : "question_61", "Strongly Agree" : "question_61"};
    this.default_60 = "question_61";
    this.time_60 = 1;
    this.image_60 = null;

    this.answer_61= ["Strongly Disagree", "Somewhat Disagree", "Neither Agree nor Disagree", "Somewhat Agree", "Strongly Agree"];
    this.question_61 = "COVID-19 limited my access to learning resources (books, teachers, websites).";
    this.routes_61 = {"Strongly Disagree": "question_62", "Somewhat Disagree" : "question_62", "Neither Agree nor Disagree" : "question_62", "Somewhat Agree" : "question_62", "Strongly Agree" : "question_62"};
    this.default_61 = "question_62";
    this.time_61 = 1;
    this.image_61 = null;

    this.answer_62= ["Strongly Disagree", "Somewhat Disagree", "Neither Agree nor Disagree", "Somewhat Agree", "Strongly Agree"];
    this.question_62 = "I had to change the methods that I usually use to learn and study.";
    this.routes_62 = {"Strongly Disagree": "question_63", "Somewhat Disagree" : "question_63", "Neither Agree nor Disagree" : "question_63", "Somewhat Agree" : "question_63", "Strongly Agree" : "question_63"};
    this.default_62 = "question_63";
    this.time_62 = 1;
    this.image_62 = null;

    this.answer_63= ["Strongly Disagree", "Somewhat Disagree", "Neither Agree nor Disagree", "Somewhat Agree", "Strongly Agree"];
    this.question_63 = "I think that I generally achieved higher grades than I would have if I had sat physical exams in the exam period of 2020 and 2021.";
    this.routes_63 = {"Strongly Disagree": "question_64", "Somewhat Disagree" : "question_64", "Neither Agree nor Disagree" : "question_64", "Somewhat Agree" : "question_64", "Strongly Agree" : "question_63"};
    this.default_63 = "question_64";
    this.time_63 = 1;
    this.image_63 = null;

    this.answer_64= ["Strongly Disagree", "Somewhat Disagree", "Neither Agree nor Disagree", "Somewhat Agree", "Strongly Agree"];
    this.question_64 = "COVID-19 has meant that I do not know as much content as I would have liked at the start of my degree course.";
    this.routes_64 = {"Strongly Disagree": "question_65", "Somewhat Disagree" : "question_65", "Neither Agree nor Disagree" : "question_65", "Somewhat Agree" : "question_65", "Strongly Agree" : "question_65"};
    this.default_64 = "question_65";
    this.time_64 = 1;
    this.image_64 = null;

    this.answer_65 = ["next"];
    this.question_65 = "Thank you for your participation in this study. When you click Next you will be taken to a submission page.";
    this.routes_65 = {"next" : "submit"};
    this.default_65 = "submit";
    this.time_65 = 1;
    this.image_65 = null;

    this.redirecting = false;
    this.default_location = "/question_3";
    this.started = false;

// In our Router configuration



    this.answers = {};
    this.answers[0] = false;
    for(var i = 1; i < 65; i++){
      this.answers[i] = "No Answer";
    }
    this.timestamp = [(new Date())];
  }
  componentDidMount() {
    console.log(this.inputRef.current);
    this.inputRef.current.focus();
  }
  secondsToTime(secs){
    let hours = Math.floor(secs / (60 * 60));

    let divisor_for_minutes = secs % (60 * 60);
    let minutes = Math.floor(divisor_for_minutes / 60);

    let divisor_for_seconds = divisor_for_minutes % 60;
    let seconds = Math.ceil(divisor_for_seconds);

    let obj = {
      "h": hours,
      "m": minutes,
      "s": seconds
    };
    return obj;
  }

  startTimer(default_location) {
    this.default_location = default_location;
    if (this.timer == 0 && this.state.seconds > 0) {
      this.timer = setInterval(this.countDown, 1000);
    }
  }

  countDown() {
    // Remove one second, set state so a re-render happens.
    let seconds = this.state.seconds - 1;
    this.setState({
      time: this.secondsToTime(seconds),
      seconds: seconds,
    });

    // Check if we're at zero.
    if (seconds == 0) {
      clearInterval(this.timer);
      this.answers[0] = true;
      this.setState({redirecting: true});
      console.log(this.state)

    }
  }

  endTimer(){
    this.answers[0] = false;
    clearInterval(this.timer);
    this.setState({
      time: 0,
      seconds: 0,
    });

  }

  resetTimer(default_location){
    if(!this.reset){
      this.reset = true;
      this.seconds = 1200;
      this.timer = 0;
      this.startTimer(default_location);
    }
  }

  render(){
    return (

      <div className="App">

      <div ref={this.inputRef}>
        m: {this.state.time.m} s: {this.state.time.s}
      </div>
      <div id="view"></div>
        <div className="box">
        <MemoryRouter>
      <Route exact path="/">
        <Redirect from="/" to="/question_1" />
        </Route>
          <Route path="/question_1" render={(props) => (<SurveyQuestion question={this.question_1} answer={this.answer_1} routes={this.routes_1} submitted_answers={this.answers} number={1} default={this.default_1} image={this.image_1}/>)} / >
          <Route path="/question_2" render={(props) => (<SurveyQuestion question={this.question_2} answer={this.answer_2} routes={this.routes_2} submitted_answers={this.answers} number={2} default={this.default_2} image={this.image_2} math={this.image_2}/>)} / >
          <Route path="/question_3" render={(props) => (<SurveyMath question={this.question_3} answer={this.answer_3} routes={this.routes_3} submitted_answers={this.answers} number={3} default={this.default_3} image={this.image_3} math={this.math_3}/>)} / >
          <Route path="/question_4" render={(props) => (<SurveyQuestion question={this.question_4} answer={this.answer_4} routes={this.routes_4} submitted_answers={this.answers} number={4} default={this.default_4} image={this.image_4}/>)} / >
          <Route path="/question_5" render={(props) => (<SurveyQuestion question={this.question_5} answer={this.answer_5} routes={this.routes_5} submitted_answers={this.answers} number={5} default={this.default_5} image={this.image_5}/>)} / >
          <Route path="/question_6" render={(props) => (<SurveyQuestion question={this.question_6} answer={this.answer_6} routes={this.routes_6} submitted_answers={this.answers} number={6} default={this.default_6} image={this.image_6}/>)} / >
          <Route path="/question_7" render={(props) => (<SurveyQuestion question={this.question_7} answer={this.answer_7} routes={this.routes_7} submitted_answers={this.answers} number={7} default={this.default_7} image={this.image_7}/>)} / >
          <Route path="/question_8" render={(props) => (<SurveyQuestion question={this.question_8} answer={this.answer_8} routes={this.routes_8} submitted_answers={this.answers} number={8} default={this.default_8} image={this.image_8}/>)} / >
          <Route path="/question_9" render={(props) => (<SurveyCheckbox question={this.question_9} answer={this.answer_9} routes={this.routes_9} submitted_answers={this.answers} number={9} default={this.default_9} image={this.image_9}/>)} / >
          <Route path="/question_10" render={(props) => (<SurveyQuestion question={this.question_10} answer={this.answer_10} routes={this.routes_10} submitted_answers={this.answers} number={10} default={this.default_10} image={this.image_10}/>)} / >
          <Route path="/question_11" render={(props) => (this.startTimer("/question_26"),<SurveyQuestion question={this.question_11} answer={this.answer_11} routes={this.routes_11} submitted_answers={this.answers} number={11} default={this.default_11} image={this.image_11}/>)} / >
          <Route path="/question_12" render={(props) => (<SurveyQuestion question={this.question_12} answer={this.answer_12} routes={this.routes_12} submitted_answers={this.answers} number={12} default={this.default_12} image={this.image_12}/>)} / >
          <Route path="/question_13" render={(props) => (<SurveyQuestion question={this.question_13} answer={this.answer_13} routes={this.routes_13} submitted_answers={this.answers} number={13} default={this.default_13} image={this.image_13}/>)} / >
          <Route path="/question_14" render={(props) => (<SurveyQuestion question={this.question_14} answer={this.answer_14} routes={this.routes_14} submitted_answers={this.answers} number={14} default={this.default_14} image={this.image_14}/>)} / >
          <Route path="/question_15" render={(props) => (<SurveyQuestion question={this.question_15} answer={this.answer_15} routes={this.routes_15} submitted_answers={this.answers} number={15} default={this.default_15} image={this.image_15}/>)} / >
          <Route path="/question_16" render={(props) => (<SurveyQuestion question={this.question_16} answer={this.answer_16} routes={this.routes_16} submitted_answers={this.answers} number={16} default={this.default_16} image={this.image_16}/>)} / >
          <Route path="/question_17" render={(props) => (<SurveyQuestion question={this.question_17} answer={this.answer_17} routes={this.routes_17} submitted_answers={this.answers} number={17} default={this.default_17} image={this.image_17}/>)} / >
          <Route path="/question_18" render={(props) => (<SurveyQuestion question={this.question_18} answer={this.answer_18} routes={this.routes_18} submitted_answers={this.answers} number={18} default={this.default_18} image={this.image_18}/>)} / >
          <Route path="/question_19" render={(props) => (<SurveyQuestion question={this.question_19} answer={this.answer_19} routes={this.routes_19} submitted_answers={this.answers} number={19} default={this.default_19} image={this.image_19}/>)} / >
          <Route path="/question_20" render={(props) => (<SurveyQuestion question={this.question_20} answer={this.answer_20} routes={this.routes_20} submitted_answers={this.answers} number={20} default={this.default_20} image={this.image_20}/>)} / >
          <Route path="/question_21" render={(props) => (<SurveyQuestion question={this.question_21} answer={this.answer_21} routes={this.routes_21} submitted_answers={this.answers} number={21} default={this.default_21} image={this.image_21}/>)} / >
          <Route path="/question_22" render={(props) => (<SurveyQuestion question={this.question_22} answer={this.answer_22} routes={this.routes_22} submitted_answers={this.answers} number={22} default={this.default_22} image={this.image_22}/>)} / >
          <Route path="/question_23" render={(props) => (<SurveyQuestion question={this.question_23} answer={this.answer_23} routes={this.routes_23} submitted_answers={this.answers} number={23} default={this.default_23} image={this.image_23}/>)} / >
          <Route path="/question_24" render={(props) => (<SurveyQuestion question={this.question_24} answer={this.answer_24} routes={this.routes_24} submitted_answers={this.answers} number={24} default={this.default_24} image={this.image_24}/>)} / >
          <Route path="/question_25" render={(props) => (<SurveyQuestion question={this.question_25} answer={this.answer_25} routes={this.routes_25} submitted_answers={this.answers} number={25} default={this.default_25} image={this.image_25}/>)} / >
          <Route path="/question_26" render={(props) => (this.endTimer, <SurveyQuestion question={this.question_26} answer={this.answer_26} routes={this.routes_26} submitted_answers={this.answers} number={26} default={this.default_26} image={this.image_26}/>)} / >
          <Route path="/question_27" render={(props) => (this.resetTimer("/question_41"),<SurveyQuestion question={this.question_27} answer={this.answer_27} routes={this.routes_27} submitted_answers={this.answers} number={27} default={this.default_27} image={this.image_27}/>)} / >
          <Route path="/question_28" render={(props) => (<SurveyQuestion question={this.question_28} answer={this.answer_28} routes={this.routes_28} submitted_answers={this.answers} number={28} default={this.default_28} image={this.image_28}/>)} / >
          <Route path="/question_29" render={(props) => (<SurveyQuestion question={this.question_29} answer={this.answer_29} routes={this.routes_29} submitted_answers={this.answers} number={29} default={this.default_29} image={this.image_29}/>)} / >
          <Route path="/question_30" render={(props) => (<SurveyQuestion question={this.question_30} answer={this.answer_30} routes={this.routes_30} submitted_answers={this.answers} number={30} default={this.default_30} image={this.image_30}/>)} / >
          <Route path="/question_31" render={(props) => (<SurveyQuestion question={this.question_31} answer={this.answer_31} routes={this.routes_31} submitted_answers={this.answers} number={31} default={this.default_31} image={this.image_31}/>)} / >
          <Route path="/question_32" render={(props) => (<SurveyQuestion question={this.question_32} answer={this.answer_32} routes={this.routes_32} submitted_answers={this.answers} number={32} default={this.default_32} image={this.image_32}/>)} / >
          <Route path="/question_33" render={(props) => (<SurveyQuestion question={this.question_33} answer={this.answer_33} routes={this.routes_33} submitted_answers={this.answers} number={33} default={this.default_33} image={this.image_33}/>)} / >
          <Route path="/question_34" render={(props) => (<SurveyQuestion question={this.question_34} answer={this.answer_34} routes={this.routes_34} submitted_answers={this.answers} number={34} default={this.default_34} image={this.image_34}/>)} / >
          <Route path="/question_35" render={(props) => (<SurveyQuestion question={this.question_35} answer={this.answer_35} routes={this.routes_35} submitted_answers={this.answers} number={35} default={this.default_35} image={this.image_35}/>)} / >
          <Route path="/question_36" render={(props) => (<SurveyQuestion question={this.question_36} answer={this.answer_36} routes={this.routes_36} submitted_answers={this.answers} number={36} default={this.default_36} image={this.image_36}/>)} / >
          <Route path="/question_37" render={(props) => (<SurveyQuestion question={this.question_37} answer={this.answer_37} routes={this.routes_37} submitted_answers={this.answers} number={37} default={this.default_37} image={this.image_37}/>)} / >
          <Route path="/question_38" render={(props) => (<SurveyQuestion question={this.question_38} answer={this.answer_38} routes={this.routes_38} submitted_answers={this.answers} number={38} default={this.default_38} image={this.image_38}/>)} / >
          <Route path="/question_39" render={(props) => (<SurveyQuestion question={this.question_39} answer={this.answer_39} routes={this.routes_39} submitted_answers={this.answers} number={39} default={this.default_39} image={this.image_39}/>)} / >
          <Route path="/question_40" render={(props) => (<SurveyQuestion question={this.question_40} answer={this.answer_40} routes={this.routes_40} submitted_answers={this.answers} number={40} default={this.default_40} image={this.image_40}/>)} / >
          <Route path="/question_41" render={(props) => (this.endTimer, <SurveyQuestion question={this.question_41} answer={this.answer_41} routes={this.routes_41} submitted_answers={this.answers} number={41} default={this.default_41} image={this.image_41}/>)} / >
          <Route path="/question_42" render={(props) => (<SurveyQuestion question={this.question_42} answer={this.answer_42} routes={this.routes_42} submitted_answers={this.answers} number={42} default={this.default_42} image={this.image_42}/>)} / >
          <Route path="/question_43" render={(props) => (<SurveyQuestion question={this.question_43} answer={this.answer_43} routes={this.routes_43} submitted_answers={this.answers} number={43} default={this.default_43} image={this.image_43}/>)} / >
          <Route path="/question_44" render={(props) => (<SurveyQuestion question={this.question_44} answer={this.answer_44} routes={this.routes_44} submitted_answers={this.answers} number={44} default={this.default_44} image={this.image_44}/>)} / >
          <Route path="/question_45" render={(props) => (<SurveyQuestion question={this.question_45} answer={this.answer_45} routes={this.routes_45} submitted_answers={this.answers} number={45} default={this.default_45} image={this.image_45}/>)} / >
          <Route path="/question_46" render={(props) => (<SurveyQuestion question={this.question_46} answer={this.answer_46} routes={this.routes_46} submitted_answers={this.answers} number={46} default={this.default_46} image={this.image_46}/>)} / >
          <Route path="/question_47" render={(props) => (<SurveyQuestion question={this.question_47} answer={this.answer_47} routes={this.routes_47} submitted_answers={this.answers} number={47} default={this.default_47} image={this.image_47}/>)} / >
          <Route path="/question_48" render={(props) => (<SurveyQuestion question={this.question_48} answer={this.answer_48} routes={this.routes_48} submitted_answers={this.answers} number={48} default={this.default_48} image={this.image_48}/>)} / >
          <Route path="/question_49" render={(props) => (<SurveyQuestion question={this.question_49} answer={this.answer_49} routes={this.routes_49} submitted_answers={this.answers} number={49} default={this.default_49} image={this.image_49}/>)} / >
          <Route path="/question_50" render={(props) => (<SurveyQuestion question={this.question_50} answer={this.answer_50} routes={this.routes_50} submitted_answers={this.answers} number={50} default={this.default_50} image={this.image_50}/>)} / >
          <Route path="/question_51" render={(props) => (<SurveyQuestion question={this.question_51} answer={this.answer_51} routes={this.routes_51} submitted_answers={this.answers} number={51} default={this.default_51} image={this.image_51}/>)} / >
          <Route path="/question_52" render={(props) => (<SurveyQuestion question={this.question_52} answer={this.answer_52} routes={this.routes_52} submitted_answers={this.answers} number={52} default={this.default_52} image={this.image_52}/>)} / >
          <Route path="/question_53" render={(props) => (<SurveyQuestion question={this.question_53} answer={this.answer_53} routes={this.routes_53} submitted_answers={this.answers} number={53} default={this.default_53} image={this.image_53}/>)} / >
          <Route path="/question_54" render={(props) => (<SurveyQuestion question={this.question_54} answer={this.answer_54} routes={this.routes_54} submitted_answers={this.answers} number={54} default={this.default_54} image={this.image_54}/>)} / >
          <Route path="/question_55" render={(props) => (<SurveyQuestion question={this.question_55} answer={this.answer_55} routes={this.routes_55} submitted_answers={this.answers} number={55} default={this.default_55} image={this.image_55}/>)} / >
          <Route path="/question_56" render={(props) => (<SurveyQuestion question={this.question_56} answer={this.answer_56} routes={this.routes_56} submitted_answers={this.answers} number={56} default={this.default_56} image={this.image_56}/>)} / >
          <Route path="/question_57" render={(props) => (<SurveyQuestion question={this.question_57} answer={this.answer_57} routes={this.routes_57} submitted_answers={this.answers} number={57} default={this.default_57} image={this.image_57}/>)} / >
          <Route path="/question_58" render={(props) => (<SurveyQuestion question={this.question_58} answer={this.answer_58} routes={this.routes_58} submitted_answers={this.answers} number={58} default={this.default_58} image={this.image_58}/>)} / >
          <Route path="/question_59" render={(props) => (<SurveyQuestion question={this.question_59} answer={this.answer_59} routes={this.routes_59} submitted_answers={this.answers} number={59} default={this.default_59} image={this.image_59}/>)} / >
          <Route path="/question_60" render={(props) => (<SurveyQuestion question={this.question_60} answer={this.answer_60} routes={this.routes_60} submitted_answers={this.answers} number={60} default={this.default_60} image={this.image_60}/>)} / >
          <Route path="/question_61" render={(props) => (<SurveyQuestion question={this.question_61} answer={this.answer_61} routes={this.routes_61} submitted_answers={this.answers} number={61} default={this.default_61} image={this.image_61}/>)} / >
          <Route path="/question_62" render={(props) => (<SurveyQuestion question={this.question_62} answer={this.answer_62} routes={this.routes_62} submitted_answers={this.answers} number={62} default={this.default_62} image={this.image_62}/>)} / >
          <Route path="/question_63" render={(props) => (<SurveyQuestion question={this.question_63} answer={this.answer_63} routes={this.routes_63} submitted_answers={this.answers} number={63} default={this.default_63} image={this.image_63}/>)} / >
          <Route path="/question_64" render={(props) => (<SurveyQuestion question={this.question_64} answer={this.answer_64} routes={this.routes_64} submitted_answers={this.answers} number={64} default={this.default_64} image={this.image_64}/>)} / >
          <Route path="/question_65" render={(props) => (<SurveyQuestion question={this.question_65} answer={this.answer_65} routes={this.routes_65} submitted_answers={this.answers} number={65} default={this.default_65} image={this.image_65}/>)} / >
          <Route path="/submit" render={(props) => (<SubmitButton submitted_answers={this.answers} time={this.timestamp}/>)} />
          <Route path="/submitted" render={(props) => (this.endTimer, <SubmitPage time={this.answers}/>)} />
          <Route path="/email" render={(props) => (<SurveyEmail submitted_answers={this.answers} default={"/question_5"} timer={this.timestamp}/>)} />
        </MemoryRouter>
        </div>

      </div>
    );
  }
}

export default App;
